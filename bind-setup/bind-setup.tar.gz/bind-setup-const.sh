CONFIGS_4_PREFIX="configs-rhel4"

declare -a CONFIGS_4=(
etc/named.conf
etc/rndc.key
etc/rndc.conf
etc/sysconfig/named
var/named/named.ca
var/named/localdomain.zone
var/named/localhost.zone
var/named/named.local
var/named/named.ip6.local
var/named/named.broadcast
var/named/named.zero
)

CONFIGS_5_PREFIX="configs-rhel5"

declare -a CONFIGS_5=(
var/named/localhost.zone
var/named/named.zero
var/named/localdomain.zone
var/named/named.ip6.local
var/named/named.broadcast
var/named/named.ca
var/named/named.local
etc/named.conf
etc/sysconfig/named 
etc/named.rfc1912.zones
)

CONFIGS_6_PREFIX="configs-rhel6" 

declare -a CONFIGS_6=(
var/named/named.empty 
var/named/named.loopback
var/named/named.ca
var/named/named.localhost
var/named/data/named.run
etc/named.conf 
etc/sysconfig/named 
etc/named.rfc1912.zones
etc/rndc.key
)

CONFIGS_7_PREFIX="configs-rhel7"

declare -a CONFIGS_7=("${CONFIGS_6[@]}")

# Does not require its own configuration, 
CONFIGS_8_PREFIX="configs-rhel7"

declare -a CONFIGS_8=("${CONFIGS_6[@]}")


CONFIGS_COMMON_PREFIX="configs-common"
